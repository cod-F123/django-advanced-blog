from django.test import TestCase
from django.utils import timezone

from accounts.models import User
from ..forms import PostForm

class TestPostForm(TestCase):

    def test_form_with_valid_data(self):
        author = User.objects.create(email="test@test.com",).profile
        form = PostForm(data = {
            "title" : "test",
            "content" : "description",
            "author" : author
        })

        self.assertTrue(form.is_valid())

    def test_form_with_no_date(self):
        form = PostForm(data = {})

        self.assertFalse(form.is_valid())