from django.test import TestCase
from django.utils import timezone
from accounts.models import User
from ..models import Post, Category


class TestPostModel(TestCase):

    def setUp(self):
        self.author = User.objects.create(email = "email@test.com").profile
        self.category = Category.objects.create(name = "test")

    def test_create_post_with_valid_data(self):

        post = Post.objects.create(
            title = "test",
            content = "description",
            author = self.author,
            category = self.category,
            published_date = timezone.now(),
            status = True
        )

        self.assertTrue(Post.objects.filter(pk = post.pk).exists())
        self.assertEqual(post.title, "test")
        