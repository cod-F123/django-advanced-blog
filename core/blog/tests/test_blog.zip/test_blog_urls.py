from django.test import TestCase, SimpleTestCase
from django.urls import reverse, resolve
from .. import views

# Create your tests here.

class TestUrl(TestCase):

    def test_blog_index_url_resolve(self):
        url = reverse("blog:index")

        self.assertEqual(resolve(url).func.view_class, views.IndexView)

    def test_blog_post_list_url_resolve(self):
        url = reverse('blog:list')

        self.assertEqual(resolve(url).func.view_class, views.PostList)

    def test_blog_post_detail_url_resolve(self):
        url = reverse('blog:detail', kwargs={'pk':1})

        self.assertEqual(resolve(url).func.view_class, views.PostDetailView)
        