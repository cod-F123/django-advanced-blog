from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from accounts.models import User
from ..models import Post

class TestBlogView(TestCase):

    def setUp(self):
        self.client = Client()

        self.user = User.objects.create(email = "email@test.com")
        self.post = Post.objects.create(
            title = "test",
            content = "description",
            author = self.user.profile,
            category = None,
            published_date = timezone.now(),
            status = True
        )

    def test_index_view_successful_response(self):
        url = reverse('blog:index')
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response=response, template_name='index.html')

    def test_post_detail_with_logged_in_user(self):

        self.client.force_login(self.user)
        url = reverse('blog:detail', kwargs={'pk':self.post.id})

        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)

    def test_post_detail_with_anonayous_user(self):
        url = reverse('blog:detail', kwargs={'pk':self.post.id})

        response = self.client.get(url)

        self.assertEqual(response.status_code, 302)